<?php
DEFINE('DBHost','10.10.10.37');
DEFINE('DBUser', 'root');
DEFINE('DBPass','');
DEFINE('DBName','EInsurance');
DEFINE('DBCharset','utf8mb4');
DEFINE('DBCollation', 'utf8_general_ci');
DEFINE('DBPrefix', '');
?>
